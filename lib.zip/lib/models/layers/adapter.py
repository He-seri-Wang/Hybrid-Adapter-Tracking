import torch
from torch import nn
import timm
import math


'''
def forward_block(self, x):
    x = x + self.drop_path(self.attn(self.norm1(x))) + self.drop_path(self.adapter_attn(self.norm1(x))) * self.s
    x = x + self.drop_path(self.mlp(self.norm2(x))) + self.drop_path(self.adapter_mlp(self.norm2(x))) * self.s
    return x


def forward_block_attn(self, x):
    x = x + self.drop_path(self.attn(self.norm1(x))) + self.drop_path(self.adapter_attn(self.norm1(x))) * self.s
    x = x + self.drop_path(self.mlp(self.norm2(x)))
    return x
'''


class QuickGELU(nn.Module):
    def forward(self, x: torch.Tensor):
        return x * torch.sigmoid(1.702 * x)


class Bi_direct_adapter(nn.Module):
    def __init__(self, dim=8, xavier_init=False):
        super().__init__()

        self.adapter_down = nn.Linear(768, dim)  
        self.adapter_up = nn.Linear(dim, 768)  
        self.adapter_mid = nn.Linear(dim, dim)

        #nn.init.xavier_uniform_(self.adapter_down.weight)
        nn.init.zeros_(self.adapter_mid.bias)
        nn.init.zeros_(self.adapter_mid.weight)
        nn.init.zeros_(self.adapter_down.weight)
        nn.init.zeros_(self.adapter_down.bias)
        nn.init.zeros_(self.adapter_up.weight)
        nn.init.zeros_(self.adapter_up.bias)

        #self.act = QuickGELU()
        self.dropout = nn.Dropout(0.1)
        self.dim = dim

    def forward(self, x):
        B, N, C = x.shape
        x_down = self.adapter_down(x)   
        #x_down = self.act(x_down)
        x_down = self.adapter_mid(x_down)
        #x_down = self.act(x_down)
        x_down = self.dropout(x_down)
        x_up = self.adapter_up(x_down)  
        #print("return adap x", x_up.size())
        return x_up

class conditional_adapter_v1(nn.Module):
    def __init__(self):
        super().__init__()
        

    def forward(self, x, x_cond):

        x = x + x_cond

        return x


class conditional_adapter_v2(nn.Module):
    def __init__(self, dim=768, r=64, dropout=0.1, use_ln=True):
        super().__init__()
        self.ln = nn.LayerNorm(dim) if use_ln else nn.Identity()
        self.drop = nn.Dropout(dropout)

        self.cond_down = nn.Linear(dim, r, bias=False)
        self.x_down    = nn.Linear(dim, r, bias=False)
        self.act = nn.GELU()

        self.delta_up = nn.Linear(r, dim, bias=True)
        self.gate_up  = nn.Linear(r, dim, bias=True)

        nn.init.zeros_(self.delta_up.weight); nn.init.zeros_(self.delta_up.bias)
        nn.init.zeros_(self.gate_up.weight);  nn.init.zeros_(self.gate_up.bias)

    def forward(self, x, x_cond):
        hc = self.act(self.cond_down(self.ln(x_cond)))
        hx = self.act(self.x_down(x))
        h = self.drop(hc + hx)

        delta = self.delta_up(h)                 # 初始≈0
        gate  = torch.sigmoid(self.gate_up(h))   # 初始≈0.5，但 delta≈0 => 仍接近 identity
        return x + gate * delta

class conditional_adapter_v3(nn.Module):
    def __init__(self, dim=768, r=64, dropout=0.1, use_ln=True,
                 num_groups=8, gate_bias=-6.0, gamma_clamp=0.2):
        super().__init__()
        assert dim % num_groups == 0
        self.dim = dim
        self.r = r
        self.num_groups = num_groups
        self.group_dim = dim // num_groups
        self.gamma_clamp = gamma_clamp

        self.ln_x = nn.LayerNorm(dim) if use_ln else nn.Identity()
        self.ln_c = nn.LayerNorm(dim) if use_ln else nn.Identity()
        self.drop = nn.Dropout(dropout)
        self.act  = nn.SiLU()

        # cond -> grouped gamma/beta
        self.cond2gb = nn.Linear(dim, 2 * num_groups, bias=True)
        nn.init.zeros_(self.cond2gb.weight)
        nn.init.zeros_(self.cond2gb.bias)

        # delta branch
        self.down = nn.Linear(dim, r, bias=False)
        self.up   = nn.Linear(r, dim, bias=True)
        nn.init.zeros_(self.up.weight)
        nn.init.zeros_(self.up.bias)

        # scalar cross-gate: depends on pooled (x, c), init gate≈0
        self.gate_x = nn.Linear(dim, 1, bias=False)
        self.gate_c = nn.Linear(dim, 1, bias=False)
        nn.init.zeros_(self.gate_x.weight)
        nn.init.zeros_(self.gate_c.weight)
        self.gate_b = nn.Parameter(torch.tensor(gate_bias))

        self.delta_scale = nn.Parameter(torch.tensor(1.0))

    def _apply_group_film(self, x, gamma_g, beta_g):
        orig = x.shape
        x = x.view(*orig[:-1], self.num_groups, self.group_dim)
        x = x * (1.0 + gamma_g.unsqueeze(-1)) + beta_g.unsqueeze(-1)
        return x.view(*orig)

    def _pool(self, t):
        # token pooling for stability if [B,N,D]
        return t.mean(dim=1) if t.dim() == 3 else t

    def forward(self, x, x_cond):
        x0 = x
        x_n = self.ln_x(x)
        c_n = self.ln_c(x_cond)

        # grouped FiLM
        gb = self.cond2gb(c_n)
        gamma_g, beta_g = gb.chunk(2, dim=-1)
        gamma_g = torch.tanh(gamma_g) * self.gamma_clamp
        x_mod = self._apply_group_film(x_n, gamma_g, beta_g)

        # delta
        h = self.act(self.down(x_mod))
        h = self.drop(h)
        delta = self.up(h) * self.delta_scale

        # scalar gate from pooled x,c (very stable)
        px = self._pool(x_n)
        pc = self._pool(c_n)
        g = torch.sigmoid(self.gate_x(px) + self.gate_c(pc) + self.gate_b)  # [B,1]
        # broadcast to x shape
        while g.dim() < x.dim():
            g = g.unsqueeze(1)
        return x0 + g * delta 
    
class conditional_adapter_v4(nn.Module):
    def __init__(self, dim=768, gate_bias=-6.0, use_ln=True):
        super().__init__()
        self.ln = nn.LayerNorm(dim) if use_ln else nn.Identity()
        self.gate = nn.Linear(dim, 1, bias=True)
        nn.init.zeros_(self.gate.weight)
        nn.init.constant_(self.gate.bias, gate_bias)

    def forward(self, x, cond):  # x:[B,N,D] or [B,D], cond:[B,N,D] or [B,D]
        if x.dim() == 2: x = x.unsqueeze(1)
        if cond.dim() == 2: cond = cond.unsqueeze(1)

        c = self.ln(cond)
        g = torch.sigmoid(self.gate(c))          # [B,N,1]  init ~0
        return x + g * cond
    
class conditional_adapter(nn.Module):
    def __init__(self, dim=768, gate_bias=-6.0, use_ln=True, dropout=0.0):
        super().__init__()
        self.ln_x = nn.LayerNorm(dim) if use_ln else nn.Identity()
        self.ln_c = nn.LayerNorm(dim) if use_ln else nn.Identity()
        self.drop = nn.Dropout(dropout)

        # token-wise scalar gate
        self.gate = nn.Linear(dim, 1, bias=True)
        nn.init.zeros_(self.gate.weight)
        nn.init.constant_(self.gate.bias, gate_bias)

    def forward(self, x, cond):
        if x.dim() == 2: x = x.unsqueeze(1)
        if cond.dim() == 2: cond = cond.unsqueeze(1)

        hx = self.ln_x(x)
        hc = self.ln_c(cond)

        g = torch.sigmoid(self.gate(self.drop(hx + hc)))   # [B,N,1], init ~0
        return x + g * cond