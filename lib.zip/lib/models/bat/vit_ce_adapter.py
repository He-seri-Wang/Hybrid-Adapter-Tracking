import math
import logging
import pdb
from functools import partial
from collections import OrderedDict
from copy import deepcopy

import torch
import torch.nn as nn
import torch.nn.functional as F

from timm.models.layers import to_2tuple

from lib.models.layers.patch_embed import PatchEmbed
from .utils import combine_tokens, recover_tokens, token2feature, feature2token
from .vit import VisionTransformer
from ..layers.attn_blocks import CEBlock, candidate_elimination_adapter

from ..layers.attn_adapt_blocks import CEABlock   ##BAT 
from ..layers.dualstream_attn_blocks import DSBlock ## Dual Stream without adapter
import torch.nn as nn
import os 
from lib.models.layers.adapter import Bi_direct_adapter

_logger = logging.getLogger(__name__)


class LoRALinear(nn.Module):

    def __init__(self, in_features: int, out_features: int, r: int = 8, lora_alpha: float = 16., lora_dropout: float = 0., bias: bool = True):
        super().__init__()

        self.in_features = in_features
        self.out_features = out_features
        self.r = r
        self.lora_alpha = lora_alpha
        self.scaling = lora_alpha / r if r > 0 else 1.0

        # ====== 原始 Linear 权重 ======
        self.weight = nn.Parameter(torch.empty(out_features, in_features))
        if bias:
            self.bias = nn.Parameter(torch.empty(out_features))
        else:
            self.bias = None

        # 初始化原始 weight/bias（和 nn.Linear 类似）
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        if self.bias is not None:
            fan_in, _ = nn.init._calculate_fan_in_and_fan_out(self.weight)
            bound = 1 / math.sqrt(fan_in)
            nn.init.uniform_(self.bias, -bound, bound)

        # 默认冻结原始 weight（LoRA 只训练低秩部分）
        self.weight.requires_grad = False
        if self.bias is not None:
            self.bias.requires_grad = False  # 如果你想训练 bias，可以改为 True

        # ====== LoRA 分支 ======
        if r > 0:
            # down: d -> r
            self.lora_down1 = nn.Linear(in_features, r, bias=False)
            self.lora_up1 = nn.Linear(r, out_features, bias=False)

            self.lora_down2 = nn.Linear(in_features, r//2, bias=False)
            self.lora_up2 = nn.Linear(r//2, out_features, bias=False)

            self.lora_down3 = nn.Linear(in_features, r*2, bias=False)
            self.lora_up3 = nn.Linear(r*2, out_features, bias=False)

            self.lora_fuse = nn.Linear(out_features*3, out_features, bias=False)

            # 初始化 LoRA：down 正常随机，up 全 0（开始时等价于原模型）
            nn.init.kaiming_uniform_(self.lora_down1.weight, a=math.sqrt(5))
            nn.init.zeros_(self.lora_up1.weight)

            nn.init.kaiming_uniform_(self.lora_down2.weight, a=math.sqrt(5))
            nn.init.zeros_(self.lora_up2.weight)

            nn.init.kaiming_uniform_(self.lora_down3.weight, a=math.sqrt(5))
            nn.init.zeros_(self.lora_up3.weight)

            # LoRA 这两个参数需要训练
            self.lora_down1.weight.requires_grad = True
            self.lora_up1.weight.requires_grad = True
            self.lora_down2.weight.requires_grad = True
            self.lora_up2.weight.requires_grad = True
            self.lora_down3.weight.requires_grad = True
            self.lora_up3.weight.requires_grad = True

            # Dropout
            if lora_dropout > 0:
                self.lora_dropout = nn.Dropout(p=lora_dropout)
            else:
                self.lora_dropout = nn.Identity()
        else:
            # 不使用 LoRA 的情况
            self.lora_down = None
            self.lora_up = None
            self.lora_dropout = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 原始 Linear 输出
        result = F.linear(x, self.weight, self.bias)

        # LoRA 分支
        if self.r > 0 and self.lora_down1 is not None:
            
            lora_out1 = self.lora_up1(self.lora_down1(self.lora_dropout(x)))
            lora_out2 = self.lora_up2(self.lora_down2(self.lora_dropout(x)))
            lora_out3 = self.lora_up3(self.lora_down3(self.lora_dropout(x)))

            lora_out = self.lora_fuse(torch.cat([lora_out1, lora_out2, lora_out3], dim=-1))
            result = result + self.scaling * lora_out

        return result
    

def _replace_linear_with_lora_in_module(module: nn.Module,
                                        r=8, lora_alpha=16, lora_dropout=0.0,
                                        target_module_name=""):
    for name, child in module.named_children():
        _replace_linear_with_lora_in_module(child, r, lora_alpha, lora_dropout, target_module_name)

        if isinstance(child, nn.Linear):
            if target_module_name != "" and target_module_name not in name:
                continue

            old_linear = child
            new_linear = LoRALinear(
                in_features=old_linear.in_features,
                out_features=old_linear.out_features,
                bias=old_linear.bias is not None,
                r=r,
                lora_alpha=lora_alpha,
                lora_dropout=lora_dropout,
            )
            new_linear.weight.data = old_linear.weight.data.clone()
            if old_linear.bias is not None and new_linear.bias is not None:
                new_linear.bias.data = old_linear.bias.data.clone()

            setattr(module, name, new_linear)


def replace_linear_with_lora_last_blocks(model: nn.Module,
                                        r=4, lora_alpha=16, lora_dropout=0,
                                        target_module_name="",
                                        block_attr="blocks",
                                        last_n_blocks=2):
    if not hasattr(model, block_attr):
        raise AttributeError(f"Model has no attribute '{block_attr}'")

    container = getattr(model, block_attr)

    # Sequential / ModuleList / list / tuple
    if isinstance(container, (nn.Sequential, nn.ModuleList, list, tuple)):
        blocks = list(container)
    else:
        raise TypeError(f"model.{block_attr} must be Sequential/ModuleList/list/tuple, got {type(container)}")

    if len(blocks) == 0:
        return model

    n = min(last_n_blocks, len(blocks))
    for blk in blocks[-n:]:
        _replace_linear_with_lora_in_module(
            blk,
            r=r, lora_alpha=lora_alpha, lora_dropout=lora_dropout,
            target_module_name=target_module_name
        )

    return model



class VisionTransformerCE(VisionTransformer):
    """ Vision Transformer with candidate elimination (CE) module

    A PyTorch impl of : `An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale`
        - https://arxiv.org/abs/2010.11929

    Includes distillation token & head support for `DeiT: Data-efficient Image Transformers`
        - https://arxiv.org/abs/2012.12877
    """

    def __init__(self, img_size=224, patch_size=16, in_chans=3, num_classes=1000, embed_dim=768, depth=12,
                 num_heads=12, mlp_ratio=4., qkv_bias=True, representation_size=None, distilled=False,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0., embed_layer=PatchEmbed, norm_layer=None,
                 act_layer=None, weight_init='', ce_loc=None, ce_keep_ratio=None, search_size=None, template_size=None,
                 new_patch_size=None, adapter_type=None):
        """
        Args:
            img_size (int, tuple): input image size
            patch_size (int, tuple): patch size
            in_chans (int): number of input channels
            num_classes (int): number of classes for classification head
            embed_dim (int): embedding dimension
            depth (int): depth of transformer
            num_heads (int): number of attention heads
            mlp_ratio (int): ratio of mlp hidden dim to embedding dim
            qkv_bias (bool): enable bias for qkv if True
            representation_size (Optional[int]): enable and set representation layer (pre-logits) to this value if set
            distilled (bool): model includes a distillation token and head as in DeiT models
            drop_rate (float): dropout rate
            attn_drop_rate (float): attention dropout rate
            drop_path_rate (float): stochastic depth rate
            embed_layer (nn.Module): patch embedding layer
            norm_layer: (nn.Module): normalization layer
            weight_init: (str): weight init scheme
            new_patch_size: backbone stride
        """
        super().__init__()
        if isinstance(img_size, tuple):
            self.img_size = img_size
        else:
            self.img_size = to_2tuple(img_size)
        self.patch_size = patch_size
        self.in_chans = in_chans

        self.num_classes = num_classes
        self.num_features = self.embed_dim = embed_dim  # num_features for consistency with other models
        self.num_tokens = 2 if distilled else 1
        norm_layer = norm_layer or partial(nn.LayerNorm, eps=1e-6)
        act_layer = act_layer or nn.GELU

        self.patch_embed = embed_layer(
            img_size=img_size, patch_size=patch_size, in_chans=in_chans, embed_dim=embed_dim)
        #self.patch_embed_adapter = embed_layer(
        #    img_size=img_size, patch_size=patch_size, in_chans=in_chans, embed_dim=embed_dim)

        # num_patches = self.patch_embed.num_patches

        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.dist_token = nn.Parameter(torch.zeros(1, 1, embed_dim)) if distilled else None
        # self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + self.num_tokens, embed_dim)) # it's redundant
        self.pos_drop = nn.Dropout(p=drop_rate)
        
        H, W = search_size
        new_P_H, new_P_W = H // new_patch_size, W // new_patch_size
        self.num_patches_search=new_P_H * new_P_W
        H, W = template_size
        new_P_H, new_P_W = H // new_patch_size, W // new_patch_size
        self.num_patches_template=new_P_H * new_P_W
        """add here, no need use backbone.finetune_track """
        self.pos_embed_z = nn.Parameter(torch.zeros(1, self.num_patches_template, embed_dim))
        self.pos_embed_x = nn.Parameter(torch.zeros(1, self.num_patches_search, embed_dim))

        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depth)]
        blocks = []
        ce_index = 0
        self.ce_loc = ce_loc
        for i in range(depth):
            ce_keep_ratio_i = 1.0
            if ce_loc is not None and i in ce_loc:
                ce_keep_ratio_i = ce_keep_ratio[ce_index]
                ce_index += 1
            if i < 20:
                blocks.append(CEABlock(dim=embed_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop_rate,
                        attn_drop=attn_drop_rate, drop_path=dpr[i], norm_layer=norm_layer, act_layer=act_layer, keep_ratio_search=ce_keep_ratio_i))
            else:
                blocks.append(DSBlock(dim=embed_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop_rate,
                        attn_drop=attn_drop_rate, drop_path=dpr[i], norm_layer=norm_layer, act_layer=act_layer, keep_ratio_search=ce_keep_ratio_i))
        

        self.blocks = nn.Sequential(*blocks)       
        self.norm = norm_layer(embed_dim)
        self.init_weights(weight_init)

    def forward_features(self, z, x, mask_z=None, mask_x=None,
                         ce_template_mask=None, ce_keep_rate=None,
                         return_last_attn=False):

        B, H, W = x.shape[0], x.shape[2], x.shape[3]
        # rgb_img
        x_rgb = x[:, :3, :, :]
        z_rgb = z[:, :3, :, :]
        # depth thermal event images
        x_dte = x[:, 3:, :, :]
        z_dte = z[:, 3:, :, :]
        # overwrite x & z
        x, z = x_rgb, z_rgb
        xi, zi = x_dte, z_dte

        z = self.patch_embed(z)
        x = self.patch_embed(x)

        xi = self.patch_embed(xi)
        zi = self.patch_embed(zi)

###################################################################===========
        # attention mask handling
        # B, H, W
        if mask_z is not None and mask_x is not None:
            mask_z = F.interpolate(mask_z[None].float(), scale_factor=1. / self.patch_size).to(torch.bool)[0]
            mask_z = mask_z.flatten(1).unsqueeze(-1)

            mask_x = F.interpolate(mask_x[None].float(), scale_factor=1. / self.patch_size).to(torch.bool)[0]
            mask_x = mask_x.flatten(1).unsqueeze(-1)

            mask_x = combine_tokens(mask_z, mask_x, mode=self.cat_mode)
            mask_x = mask_x.squeeze(-1)

        if self.add_cls_token:
            cls_tokens = self.cls_token.expand(B, -1, -1)
            cls_tokens = cls_tokens + self.cls_pos_embed

        z += self.pos_embed_z
        x += self.pos_embed_x

        zi += self.pos_embed_z
        xi += self.pos_embed_x

        if self.add_sep_seg:
            x += self.search_segment_pos_embed
            z += self.template_segment_pos_embed
            xi += self.search_segment_pos_embed      #//////////////////////////////////////////////////////////////////
            zi += self.template_segment_pos_embed
        #print(x.shape) #[Batch size, 256, 768]
        
        x = combine_tokens(z, x, mode=self.cat_mode)  ##[Batch size, 320, 768]
        #print("after cat",x.shape)

        xi = combine_tokens(zi, xi, mode=self.cat_mode)
        if self.add_cls_token:
            x = torch.cat([cls_tokens, x], dim=1)
            xi = torch.cat([cls_tokens, xi], dim=1)

        x = self.pos_drop(x)
        xi = self.pos_drop(xi)

        lens_z = self.pos_embed_z.shape[1]
        lens_x = self.pos_embed_x.shape[1]

        global_index_t = torch.linspace(0, lens_z - 1, lens_z, dtype=torch.int64).to(x.device)
        global_index_t = global_index_t.repeat(B, 1)

        global_index_s = torch.linspace(0, lens_x - 1, lens_x, dtype=torch.int64).to(x.device)
        global_index_s = global_index_s.repeat(B, 1)

        global_index_ti = torch.linspace(0, lens_z - 1, lens_z, dtype=torch.int64).to(x.device)
        global_index_ti = global_index_ti.repeat(B, 1)

        global_index_si = torch.linspace(0, lens_x - 1, lens_x, dtype=torch.int64).to(x.device)
        global_index_si = global_index_si.repeat(B, 1)

        removed_indexes_s = []
        removed_indexes_si = []

        removed_flag = False
        for i, blk in enumerate(self.blocks):
           
            x, global_index_t, global_index_s, removed_index_s, attn, \
            xi, global_index_ti, global_index_si, removed_index_si, attn_i = \
                blk(x, xi, global_index_t, global_index_ti, global_index_s, global_index_si, mask_x, ce_template_mask,
                    ce_keep_rate)
            #print(i, ": ", blk.keep_ratio_search)
            if self.ce_loc is not None and i in self.ce_loc:
                removed_indexes_s.append(removed_index_s)
                removed_indexes_si.append(removed_index_si)

              
        x = self.norm(x)
        xi = self.norm(xi)

        lens_x_new = global_index_s.shape[1]
        lens_z_new = global_index_t.shape[1]
        lens_xi_new = global_index_si.shape[1]
        lens_zi_new = global_index_ti.shape[1]

        z = x[:, :lens_z_new]
        x = x[:, lens_z_new:]
        zi = xi[:, :lens_zi_new]
        xi = xi[:, lens_zi_new:]

        if removed_indexes_s and removed_indexes_s[0] is not None:
            removed_indexes_cat = torch.cat(removed_indexes_s, dim=1)

            pruned_lens_x = lens_x - lens_x_new
            pad_x = torch.zeros([B, pruned_lens_x, x.shape[2]], device=x.device)
            x = torch.cat([x, pad_x], dim=1)
            index_all = torch.cat([global_index_s, removed_indexes_cat], dim=1)
            # recover original token order
            C = x.shape[-1]
            x = torch.zeros_like(x).scatter_(dim=1, index=index_all.unsqueeze(-1).expand(B, -1, C).to(torch.int64), src=x)
        
        if removed_indexes_si and removed_indexes_si[0] is not None:
            removed_indexes_cat_i = torch.cat(removed_indexes_si, dim=1)

            pruned_lens_xi = lens_x - lens_xi_new                                ########################
            pad_xi = torch.zeros([B, pruned_lens_xi, xi.shape[2]], device=xi.device)
            xi = torch.cat([xi, pad_xi], dim=1)
            index_all = torch.cat([global_index_si, removed_indexes_cat_i], dim=1)
            # recover original token order
            C = xi.shape[-1]
            # x = x.gather(1, index_all.unsqueeze(-1).expand(B, -1, C).argsort(1))
            xi = torch.zeros_like(xi).scatter_(dim=1, index=index_all.unsqueeze(-1).expand(B, -1, C).to(torch.int64), src=xi)
        
        x = recover_tokens(x, lens_z_new, lens_x, mode=self.cat_mode)
        xi = recover_tokens(xi, lens_zi_new, lens_x, mode=self.cat_mode)

        # re-concatenate with the template, which may be further used by other modules
        x = torch.cat([z, x], dim=1)
        xi = torch.cat([zi, xi], dim=1)
        #x = torch.cat([x, xi], dim=0)
        #print("===========final out: ",x.size())
        
        x = x + xi

        #x = torch.cat([x, xi], dim=2)
        #x = self.adap_headcat(x)


        #print("-------",x.shape)
        #print("attn",attn.size())
        aux_dict = {
            "attn": attn,
            "removed_indexes_s": removed_indexes_s,  # used for visualization
        }

        return x, aux_dict

    def forward(self, z, x, ce_template_mask=None, ce_keep_rate=None, tnc_keep_rate=None, return_last_attn=False):

        x, aux_dict = self.forward_features(z, x, ce_template_mask=ce_template_mask, ce_keep_rate=ce_keep_rate,)

        return x, aux_dict


def _create_vision_transformer(pretrained=False, **kwargs):
    model = VisionTransformerCE(**kwargs)

    if pretrained:
        if 'npz' in pretrained:
            model.load_pretrained(pretrained, prefix='')
        else:
            checkpoint = torch.load(os.path.abspath(pretrained), map_location="cpu")
            checkpoint_new = checkpoint.copy()

            for k in list(checkpoint['net'].keys()):
                if k.startswith("backbone."):
                    new_k = k.replace("backbone.", "")
                    checkpoint_new["net"][new_k] = checkpoint["net"][k]
                    checkpoint_new["net"].pop(k)
            missing_keys, unexpected_keys = model.load_state_dict(checkpoint["net"], strict=False)
            print('Load pretrained OSTrack from: ' + pretrained)
            print(f"missing_keys: {missing_keys}")
            print(f"unexpected_keys: {unexpected_keys}")

    return model


def vit_base_patch16_224_ce_adapter(pretrained=False, **kwargs):
    """ ViT-Base model (ViT-B/16) from original paper (https://arxiv.org/abs/2010.11929).
    """
    model_kwargs = dict(patch_size=16, embed_dim=768, depth=12, num_heads=12, **kwargs)
    model = _create_vision_transformer(pretrained=pretrained, **model_kwargs)

    model = replace_linear_with_lora_last_blocks(model, r=4, lora_alpha=4, lora_dropout=0.2, target_module_name='qkv', block_attr="blocks",last_n_blocks=4)

    return model


def vit_large_patch16_224_ce_adapter(pretrained=False, **kwargs):
    """ ViT-Large model (ViT-L/16) from original paper (https://arxiv.org/abs/2010.11929).
    """
    model_kwargs = dict(
        patch_size=16, embed_dim=1024, depth=24, num_heads=16, **kwargs)
    model = _create_vision_transformer(pretrained=pretrained, **model_kwargs)
    return model
