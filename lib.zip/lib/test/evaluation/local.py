from lib.test.evaluation.environment import EnvSettings

def local_env_settings():
    settings = EnvSettings()

    # Set your local paths here.

    settings.davis_dir = ''
    settings.got10k_lmdb_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/got10k_lmdb'
    settings.got10k_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/got10k'
    settings.got_packed_results_path = ''
    settings.got_reports_path = ''
    settings.itb_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/itb'
    settings.lasot_extension_subset_path_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/lasot_extension_subset'
    settings.lasot_lmdb_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/lasot_lmdb'
    settings.lasot_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/lasot'
    settings.network_path = '/home/zceehw4/BAT/output/test/networks'    # Where tracking networks are stored.
    settings.nfs_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/nfs'
    settings.otb_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/otb'
    settings.prj_dir = '/home/zceehw4/BAT_lora_adapter'
    settings.result_plot_path = '/home/zceehw4/BAT_lora_adapter/output/test/result_plots'
    settings.results_path = '/home/zceehw4/BAT_lora_adapter/output/test/tracking_results'    # Where to store tracking results
    settings.save_dir = '/home/zceehw4/BAT_lora_adapter/output'
    settings.segmentation_path = '/home/zceehw4/BAT_lora_adapter/output/test/segmentation_results'
    settings.tc128_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/TC128'
    settings.tn_packed_results_path = ''
    settings.tnl2k_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/tnl2k'
    settings.tpl_path = ''
    settings.trackingnet_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/trackingnet'
    settings.uav_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/uav'
    settings.vot18_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/vot2018'
    settings.vot22_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/vot2022'
    settings.vot_path = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/VOT2019'
    settings.youtubevos_dir = ''

    return settings

