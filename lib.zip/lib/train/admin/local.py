class EnvironmentSettings:
    def __init__(self):
        self.workspace_dir = '/home/zceehw4/BAT_lora_adapter'    # Base directory for saving network checkpoints.
        self.tensorboard_dir = '/home/zceehw4/BAT_lora_adapter/tensorboard'    # Directory for tensorboard files.
        self.pretrained_networks = '/home/zceehw4/BAT_lora_adapter/pretrained_networks'  # Directory for pretrained networks.
        self.pretrained_networks = '/home/zceehw4/BAT/pretrained_networks'
        self.got10k_val_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/got10k/val'
        self.lasot_lmdb_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/lasot_lmdb'
        self.got10k_lmdb_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/got10k_lmdb'
        self.trackingnet_lmdb_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/trackingnet_lmdb'
        self.coco_lmdb_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/coco_lmdb'
        self.coco_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/coco'
        self.lasot_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/lasot'
        self.got10k_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/got10k/train'
        self.trackingnet_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/trackingnet'
        self.depthtrack_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/depthtrack/train'
        self.lasher_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset'
        self.visevent_dir = '/scratch/zceehw4/vipt/data/LasHeR/train/trainingset/visevent/train'
